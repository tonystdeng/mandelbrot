﻿using var game = new mandelbrot.Game1();
game.Run();
